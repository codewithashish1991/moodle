The Adaptable story
===================
Adaptable is based upon the popular BCU theme, developed for Coventry University.  Since the main developer decided to leave the
project, I (Gareth) was asked to assist in maintainance and improvements.  Coventry University has now moved away from Moodle and
passed the project onto me to manage as its lead.  I will keep the theme alive, maintained and supported for as long as there is a
willingness to fund my time to do so.  The theme is complex and takes time, skill, knowledge and talent to develop.  This is why
I'm asking for your financial support in my endeavours.

If you'd like to sponsor, get support or fund improvements, then please do get in touch via:

- gjbarnard | Gmail dt com address.
- GitLab | Please outline your issue / improvement on '[Adaptable issues](https://gitlab.com/jezhops/moodle-theme_adaptable/-/issues)'.
- @gjbarnard | '[Twitter](https://twitter.com/gjbarnard)'.

Open source software
====================
As Adaptable is licensed under the [GNU GPLv3](https://www.gnu.org/licenses/gpl-3.0.en.html) License it comes with NO support,
please see 'COPYING.txt'. If you would like support from me then I'm happy to provide it for a fee (please see my contact details
below).  Otherwise, the Moodle '[Themes](https://moodle.org/mod/forum/view.php?id=46)' forum is an excellent place to ask questions.

Adaptable can be obtained from:

* [Moodle.org](https://moodle.org/plugins/theme_adaptable).
* [GitLab](https://gitlab.com/jezhops/moodle-theme_adaptable/-/releases).

You have all the rights granted to you by the GPLv3 license.  If you are unsure about anything, then the
FAQ - [GPL FAQ](https://www.gnu.org/licenses/gpl-faq.html) - is a good place to look.

If you reuse any of the code then I kindly ask that you make reference to the theme.

If you make improvements or bug fixes then I would appreciate if you would send them back to me by forking from
[GitLab](https://gitlab.com/jezhops/moodle-theme_adaptable) and doing a 'Pull Request' so that the rest of the Moodle community
benefits.

Required version of Moodle
==========================
This version works with Moodle 3.11 version 2021051700.00 (Build: 20210517) and above within the 3.11 branch until the next release.

Please ensure that your hardware and software complies with 'Requirements' in '[Installing Moodle](https://docs.moodle.org/311/en/Installing_Moodle)'.

Known issues
================
See 'Known issues with this version' in 'Changes.md' for the version you are running.

Reporting issues
================
Before reporting an issue, please ensure that you are running the [current](https://moodle.org/plugins/theme_adaptable) version for
the major release of Moodle you are using.  It is essential that you are operating the required version of Moodle as stated above,
this is because the theme relies on core functionality that is out of its control.

If you think you've discovered a genuine bug with the theme then please look at the Moodle Themes forum first to see if it
has already been repoted.  Secondly, look at [GitLab](https://gitlab.com/jezhops/moodle-theme_adaptable/-/issues).

I operate a policy that I will fix all genuine issues in 'my' (not other developers of the theme) code, when fully described and
replicatable.

It is essential that you provide as much information as possible, the critical information being the contents of the theme's
version.php file / or the top of the 'Information' settings tab.  Other version information such as specific Moodle version,
theme name and version also helps.  A screen shot can be really useful in visualising the issue along with any files you
consider to be relevant.

You can use either the '[Themes forum](https://moodle.org/mod/forum/view.php?id=46)' or '[GitLab](https://gitlab.com/jezhops/moodle-theme_adaptable/-/issues)'.

Currently developed and maintained by
=====================================
G J Barnard MSc. BSc(Hons)(Sndw). MBCS. CEng. CITP. PGCE.

- Moodle profile | [Moodle.org](http://moodle.org/user/profile.php?id=442195)
- @gjbarnard | [Twitter](https://twitter.com/gjbarnard).
- Web profile | [About.me](http://about.me/gjbarnard)
